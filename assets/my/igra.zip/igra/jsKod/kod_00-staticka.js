class Postavke{

    constructor(){
        if(this instanceof Postavke){
            throw new Error("Staticka klasa nema instance!");
        }
    }

    /** @type {Igrac} */
    static igrac;

    /** @type {Potion} */
    static potion;

    /** @type {Gorivo} */
    static gorivo;

    /** @type {Blato} */
    static blato;

    /** @type {Kamen} */
    static kamen;

    /** @type {Enemy} */
    static enemy;

    static dno = 9*32;
    static signal = 3;



    static random(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
    

  }

}