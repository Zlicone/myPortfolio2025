//#region okvir
/// <reference path="../otter/lib-00-GameSettings.js"/>
/// <reference path="../otter/lib-01-tiled.js"/>
/// <reference path="../otter/lib-02-sensing.js"/>
/// <reference path="../otter/lib-03-display.js"/>
/// <reference path="../otter/lib-04-engine.js"/>
/// <reference path="../otter/lib-05-game.js"/>
/// <reference path="../otter/lib-06-main.js"/>
//#endregion

class Ziv extends Sprite {
  constructor (x,y,layer){
    super(x + 2, y + 2, 32, 32);

    this.frame_sets={};

    this.layer=layer;
    this.visible=true;

    if(this.constructor == Ziv){
      throw new Error("Ne moze se instancirat");
    }
  }

  jump(h=30){
    if(!this.jumping){
      this.jumping=true;
      this.velocity_y-=h;
    }
  }
}

class Enemy extends Ziv{
  constructor(layer){
    super(0,0,layer);
    this.visible=false;

    this.frame_sets={
      "up": [1],
      "walk-up": [1],
      "right": [5,6,7,8,9,10],
      "walk-right": [47,48,49,50,51,52],
      "down": [1],
      "walk-down": [1],
      "left": [11,12,13,14,15,16],
      "walk-left": [53,54,55,56,57,58],
    };

    this.startx=24*32;
    this.endx=36*32;
    this.state="desno";
    this.pokrenut=false;
  }
  start() {
    this.x = this.startx;
    this.y = 7 * 32;
  }

  kreni(){
    if(!this.pokrenut && Postavke.igrac.bodovi === Postavke.signal){
      this.start();
      this.visible=true;
      this.pokrenut=true;
    }
  }

  patrol(){
    switch(this.state){
      case "desno":
        {
          this.velocity_x=4;
          this.direction=90;
          if(this.x>=35*32){
            this.state="livo";
          }
          break;
        }
      case "livo":
        {
          this.velocity_x=-4;
          this.direction=270;
          if(this.x<=24*32)
          {
            this.state="desno";
          }
          break;
        }
      
    }
  }
}


class Igrac extends Ziv{
  #zivoti;
  constructor(layer){
    super(0,0,layer);

    this.frame_sets={
      "up": [1],
      "walk-up": [1],
      "right": [1,2],
      "walk-right": [37,38,39,40,41],
      "down": [1],
      "walk-down": [1],
      "left": [3,4],
      "walk-left": [42,43,44,45,46],
    };
    this.okvir=true;
    this.#zivoti=3;
    this.benzin=70;
    this.bodovi=0;
  }

  get zivoti() {
      return this.#zivoti;
    }
  set zivoti(v){
    if(v<=0){
      this.#zivoti=0;
      btnStop_click();
      alert("Izgubio si");
      Prvi();
      btnStart_click();
    }
    else{
      this.#zivoti=v;
    }
  }

  updatePosition(){
    super.updatePosition(2,0.8);
    if(this.y>=Postavke.dno){
      this.start();
      this.zivoti--;
    }
  }

  pokupljen_bod(b){
    this.bodovi++;
    b.start();
    if(this.bodovi>=3){
      b.visible=false;
      return;
    }
  }

  collect(p){
    if(this.zivoti<3){
      this.zivoti += p.value;
      p.start();
    }
  }

  collect_benz(b){
    if(this.benzin<70){
      this.benzin+=b.value;
      if(this.benzin>70)this.benzin=70;
      b.start();
    }
  }

  start() {
    this.x = 0;
    this.y = 2 * 32;
    this.benzin=70;
  }

  moveRight() {
    this.direction = 90;
    this.velocity_x += 1.5;
  }

  moveLeft() {
    this.direction = 270;
    this.velocity_x -= 1.5;
  }

  jetpack(x=3){
    if(this.benzin<=0) return;
    this.benzin--;
    if(SENSING.left.active)
      this.velocity_x-=x-1;
      else if(SENSING.right.active)
        this.velocity_x+=x-1;
      else if(SENSING.up.active)
        this.velocity_y-=x;
      else{
        if(this.direction===90){
          this.velocity_x+=x-1;
        }else if(this.direction===270){
          this.velocity_x-=x-1;
        }
      }
  }

  jetpack_ne(){
    let a=arguments.length;
    if(a==1){
      let tip=typeof arguments[0];

      switch(tip){
      case "number":
        let h=arguments[0];
        jetpack(h);
      case "string":
        let vrsta=arguments[0];
        if(vrsta=="blato"){
          console.log("Nemos jetpack");
        }
        else{
          jetpack();
        }
        break;
      default:
        break;
      }
    }
    else{
      jetpack();
    }
  }
  jump(){
    let a=arguments.length;
    if(a==1){
      let tip=typeof arguments[0];

      switch(tip){
      case "number":
        let h=arguments[0];
        super.jump(h);
      case "string":
        let vrsta=arguments[0];
        if(vrsta=="blato"){
          console.log("Nemos skok");
        }
        else{
          super.jump();
        }
        break;
      default:
        break;
      }
    }
    else{
      super.jump();
    }
  }

}

class Collectable extends Item {

  constructor(layer) {
    super(layer);

    if (this.constructor == Collectable) {
      throw new Error("Collectable se ne može instancirati");
    }
  }

  getType() {
    return this.constructor.name;
  }

}

class Potion extends Collectable{
  constructor(layer){
    super(layer);
    this.visible=true;
    this.value=1;
  }
  start(){
    this.x=Postavke.random(0,9*102);
    this.y=0;
  }
}

class Gorivo extends Collectable{
  constructor(layer){
    super(layer);
    this.visible=true;
    this.value=100;
  }
  start(){
    this.x=Postavke.random(0,9*102);
    this.y=0;
  }
}

class Kamen extends Collectable{
  constructor(layer){
    super(layer);
    this.visible=true;
    this.value=1;
  }
  start(){
    this.x=Postavke.random(0,9*102);
    this.y=0;
  }
}

class Blato extends Item{
  constructor(layer){
    super(layer);
    this.visible=true;
  }
  start() {
    this.x = 6*32;
    this.y = 8 * 32;
  }
}
