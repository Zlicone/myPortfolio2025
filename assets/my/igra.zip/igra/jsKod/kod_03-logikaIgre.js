//#region okvir
/// <reference path="../otter/lib-00-GameSettings.js"/>
/// <reference path="../otter/lib-01-tiled.js"/>
/// <reference path="../otter/lib-02-sensing.js"/>
/// <reference path="../otter/lib-03-display.js"/>
/// <reference path="../otter/lib-04-engine.js"/>
/// <reference path="../otter/lib-05-game.js"/>
/// <reference path="../otter/lib-06-main.js"/>
//#endregion

/// <reference path="kod_01-likovi.js"/>
/// <reference path="kod_02-postavke.js"/>

/**
 * Promjena stanja likova - interakcije
 */
function update_main() {

  if(GAME.activeWorldMap.name == "mapa") igra();
  if(GAME.activeWorldMap.name == "mapa1") igra1();

  GAME.update();

};

function igra(){
  if (SENSING.left.active){
    Postavke.igrac.moveLeft();
  }

  if (SENSING.right.active){
    Postavke.igrac.moveRight();
  }

  if (SENSING.up.active) {
    if(Postavke.igrac.touching(Postavke.blato)){
      Postavke.igrac.jump("blato");
    }
    else{
      Postavke.igrac.jump();
    }
  }
  if(SENSING.space.active){
    if(Postavke.igrac.touching(Postavke.blato)){
      Postavke.igrac.jetpack_ne("blato");
    }
    else if(Postavke.igrac.touching(Postavke.enemy)){
      Postavke.enemy.visible=false;
      btnStop_click();
      Drugi();
      btnStart_click();
    }
    else{
      Postavke.igrac.jetpack();
    }
  }
  if(Postavke.igrac.touching(Postavke.potion)){
    Postavke.igrac.collect(Postavke.potion);
  }
  if(Postavke.igrac.touching(Postavke.gorivo)){
    Postavke.igrac.collect_benz(Postavke.gorivo);
  }
  if(Postavke.igrac.touching(Postavke.kamen)){
    Postavke.igrac.pokupljen_bod(Postavke.kamen);
  }

  if(Postavke.igrac.touching(Postavke.enemy)){
    Postavke.igrac.zivoti--;
    Postavke.igrac.start();
  }

  Postavke.enemy.kreni();
  if(Postavke.enemy.visible){
    Postavke.enemy.patrol();
  }
}

function igra1()
{
  if (SENSING.left.active){
    Postavke.igrac.moveLeft();
  }

  if (SENSING.right.active){
    Postavke.igrac.moveRight();
  }

  if (SENSING.up.active) {
    if(Postavke.igrac.touching(Postavke.blato)){
      Postavke.igrac.jump("blato");
    }
    else{
      Postavke.igrac.jump();
    }
  }

  if(SENSING.space.active){
    if(Postavke.igrac.touching(Postavke.blato)){
      Postavke.igrac.jetpack_ne("blato");
    }
    else if(Postavke.igrac.touching(Postavke.enemy)){
      Postavke.enemy.visible=false;
      btnStop_click();
      alert("Pobjeda! Play again?");
      Prvi();
      btnStart_click();
    }
    else{
      Postavke.igrac.jetpack();
    }
  }
  if(Postavke.igrac.touching(Postavke.potion)){
    Postavke.igrac.collect(Postavke.potion);
  }
  if(Postavke.igrac.touching(Postavke.gorivo)){
    Postavke.igrac.collect_benz(Postavke.gorivo);
  }
  if(Postavke.igrac.touching(Postavke.kamen)){
    Postavke.igrac.pokupljen_bod(Postavke.kamen);
  }

  if(Postavke.igrac.touching(Postavke.enemy)){
    Postavke.igrac.zivoti--;
    Postavke.igrac.start();
  }

  Postavke.enemy.kreni();
  if(Postavke.enemy.visible){
    Postavke.enemy.patrol();
  }


}
