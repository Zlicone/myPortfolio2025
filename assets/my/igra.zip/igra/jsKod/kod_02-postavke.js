//#region okvir
/// <reference path="../otter/lib-00-GameSettings.js"/>
/// <reference path="../otter/lib-01-tiled.js"/>
/// <reference path="../otter/lib-02-sensing.js"/>
/// <reference path="../otter/lib-03-display.js"/>
/// <reference path="../otter/lib-04-engine.js"/>
/// <reference path="../otter/lib-05-game.js"/>
/// <reference path="../otter/lib-06-main.js"/>
//#endregion
/// <reference path="kod_01-likovi.js"/>


// što će se pokrenuti kad se klikne button Setup:
let btnSetupGame = document.getElementById("btnSetupGame");
btnSetupGame.addEventListener("click", setup);

function Prvi(){
  GAME.clearSprites();
  GAME.setActiveWorldMap("mapa");
  setup();
}

function Drugi(){
  GAME.clearSprites();
  GAME.setActiveWorldMap("mapa1");
  setup();
}

function setup() {

  GAME.clearSprites();

  let odabrana = GAME.activeWorldMap.name;
  GameSettings.output(odabrana);

  switch (odabrana) {
    case "mapa":
      setupLevel();
      break;
    case "mapa1":
      setupLevel2();
      break;

    default:
      throw "Ne postoji setup za " + GAME.activeWorldMap.name;
      break;
  }

  render_main();
}

/* LEVELS */

function setupLevel() {
  GAME.clearSprites();

  GAME.activeWorldMap.setCollisions("stvari");

  Postavke.igrac=new Igrac(GAME.getSpriteLayer("igrac"));
  Postavke.igrac.start();
  GAME.addSprite(Postavke.igrac);

  Postavke.enemy=new Enemy(GAME.getSpriteLayer("enemy"));
  GAME.addSprite(Postavke.enemy);

  Postavke.potion=new Potion(GAME.getSpriteLayer("potion"));
  Postavke.potion.start();
  GAME.addSprite(Postavke.potion);

  Postavke.gorivo=new Gorivo(GAME.getSpriteLayer("gorivo"));
  Postavke.gorivo.start();
  GAME.addSprite(Postavke.gorivo);

  Postavke.kamen=new Kamen(GAME.getSpriteLayer("kamen"));
  Postavke.kamen.start();
  GAME.addSprite(Postavke.kamen);

  Postavke.blato=new Blato(GAME.getSpriteLayer("blato"));
  Postavke.blato.start();
  GAME.addSprite(Postavke.blato);

  igra();

}

function setupLevel2(){
  GAME.clearSprites();

  GAME.activeWorldMap.setCollisions("stvari");

  Postavke.igrac=new Igrac(GAME.getSpriteLayer("igrac"));
  Postavke.igrac.start();
  GAME.addSprite(Postavke.igrac);

  Postavke.enemy=new Enemy(GAME.getSpriteLayer("enemy"));
  GAME.addSprite(Postavke.enemy);

  Postavke.potion=new Potion(GAME.getSpriteLayer("potion"));
  Postavke.potion.start();
  GAME.addSprite(Postavke.potion);

  Postavke.gorivo=new Gorivo(GAME.getSpriteLayer("gorivo"));
  Postavke.gorivo.start();
  GAME.addSprite(Postavke.gorivo);

  Postavke.kamen=new Kamen(GAME.getSpriteLayer("kamen"));
  Postavke.kamen.start();
  GAME.addSprite(Postavke.kamen);

  Postavke.blato=new Blato(GAME.getSpriteLayer("blato"));
  Postavke.blato.start();
  GAME.addSprite(Postavke.blato);

  igra1();
}
