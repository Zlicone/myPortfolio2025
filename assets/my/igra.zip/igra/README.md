# OOP - vježbe 04 - zadatak

Napomena:

* lib-05-game.js nije potpuna

