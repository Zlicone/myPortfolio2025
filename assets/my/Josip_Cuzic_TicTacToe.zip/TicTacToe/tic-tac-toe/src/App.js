import React, { useState } from 'react';

export default function TicTacToe() {
  const [board, setBoard] = useState(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);
  const [gameOver, setGameOver] = useState(false);

  const calculateWinner = (squares) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
      [0, 4, 8], [2, 4, 6] // diagonals
    ];
    
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return null;
  };

  const winner = calculateWinner(board);
  const isDraw = !winner && board.every(square => square !== null);

  const handleClick = (i) => {
    if (board[i] || winner || isDraw) return;
    
    const newBoard = board.slice();
    newBoard[i] = isXNext ? 'X' : 'O';
    setBoard(newBoard);
    setIsXNext(!isXNext);
    
    if (calculateWinner(newBoard) || newBoard.every(square => square !== null)) {
      setGameOver(true);
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setIsXNext(true);
    setGameOver(false);
  };

  const getStatus = () => {
    if (winner) return `Pobjednik: ${winner}`;
    if (isDraw) return 'Neriješeno!';
    return `Na redu: ${isXNext ? 'X' : 'O'}`;
  };

  const Square = ({ value, onClick, index }) => (
    <button
      className={`
        w-20 h-20 border-2 border-gray-300 bg-white hover:bg-gray-50 
        transition-all duration-200 text-3xl font-bold
        ${value === 'X' ? 'text-blue-600' : 'text-red-500'}
        ${!value && !gameOver ? 'hover:shadow-md cursor-pointer' : 'cursor-default'}
        ${winner && calculateWinner(board) === value ? 'bg-green-100 border-green-400' : ''}
        rounded-lg shadow-sm
      `}
      onClick={onClick}
    >
      {value}
    </button>
  );

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full">
        <h1 className="text-4xl font-bold text-center mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Tic Tac Toe
        </h1>
        
        <div className="text-center mb-6">
          <p className={`text-xl font-semibold ${
            winner ? 'text-green-600' : 
            isDraw ? 'text-orange-500' : 
            'text-gray-700'
          }`}>
            {getStatus()}
          </p>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-6 justify-center">
          {board.map((square, i) => (
            <Square
              key={i}
              value={square}
              onClick={() => handleClick(i)}
              index={i}
            />
          ))}
        </div>

        <button
          onClick={resetGame}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
        >
          Nova igra
        </button>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p>Prvi igrač: <span className="text-blue-600 font-semibold">X</span></p>
          <p>Drugi igrač: <span className="text-red-500 font-semibold">O</span></p>
        </div>
      </div>
    </div>
  );
}